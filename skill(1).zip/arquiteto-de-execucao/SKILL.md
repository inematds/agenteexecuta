---
name: arquiteto-de-execucao
description: analisa tarefas complexas antes da execução e define a arquitetura mais econômica e confiável entre sequência, paralelismo ou modelo híbrido. use quando houver agentes, subagentes, múltiplas entregas, contexto compartilhado, alto consumo de tokens, modelos diferentes, automações, renders, pesquisas, produção em lote, risco de trabalho duplicado ou necessidade de controlar custo, velocidade, consistência e handoffs.
---

# Arquiteto de Execução

Aplicar uma etapa obrigatória de arquitetura antes de iniciar trabalhos complexos. Separar raciocínio de execução, evitar agentes desnecessários e escolher conscientemente entre sequência, paralelismo e fluxo híbrido.

## Princípio central

Usar esta regra como padrão:

> Centralizar decisões, registrar o contexto, automatizar o trabalho mecânico e paralelizar somente unidades realmente independentes.

Não criar subagentes, distribuir tarefas ou iniciar processamento paralelo antes de concluir o plano de execução. Não interromper para pedir aprovação quando a tarefa puder prosseguir com segurança; apresentar o plano brevemente e continuar. Pedir confirmação apenas para ações destrutivas, gastos externos relevantes ou ambiguidades que alterem materialmente o resultado.

## Fluxo obrigatório

### 1. Definir o resultado

Extrair e registrar:

- objetivo final;
- entregáveis;
- critérios de qualidade;
- restrições de prazo, custo e ferramentas;
- dependências externas;
- pontos que exigem decisão humana.

Quando faltarem detalhes não críticos, adotar premissas razoáveis e declará-las. Não atrasar a execução por perguntas desnecessárias.

### 2. Decompor em unidades de trabalho

Dividir o projeto em tarefas pequenas o suficiente para terem:

- entrada clara;
- saída verificável;
- responsável ou executor adequado;
- dependências conhecidas;
- critério objetivo de conclusão.

Evitar dividir apenas para “usar mais agentes”. Cada divisão deve reduzir latência, especializar ferramentas ou isolar risco.

### 3. Classificar cada unidade

Classificar cada tarefa nos seguintes eixos:

- **raciocínio:** alto, médio ou baixo;
- **dependência:** bloqueante, parcial ou independente;
- **contexto compartilhado:** alto, médio ou baixo;
- **determinismo:** previsível ou aberto;
- **custo de erro:** alto, médio ou baixo;
- **urgência:** alta, média ou baixa;
- **executor:** modelo avançado, modelo econômico, script/ferramenta ou humano.

Consultar `references/decision-matrix.md` quando houver dúvida entre sequência, paralelo ou híbrido.

### 4. Escolher o modo de execução

Escolher **sequencial** quando houver uma ou mais destas condições:

- a saída de uma etapa altera a próxima;
- várias tarefas dependem do mesmo contexto extenso;
- consistência é mais importante que velocidade;
- o aprendizado de uma tarefa deve alimentar a seguinte;
- o custo de divergência ou consolidação é alto.

Escolher **paralelo** quando:

- as tarefas forem independentes;
- as entradas estiverem estabilizadas;
- o contexto por tarefa for pequeno;
- a execução for mecânica ou verificável;
- reduzir o tempo total justificar o custo adicional.

Escolher **híbrido** como padrão para projetos grandes:

1. planejar e definir padrões de forma centralizada;
2. registrar uma especificação única;
3. distribuir somente tarefas independentes;
4. executar scripts, renders, testes e conversões em paralelo;
5. reunir os resultados;
6. revisar de forma centralizada;
7. corrigir apenas os itens reprovados.

### 5. Escolher o executor mais barato que preserve qualidade

Usar modelo avançado para:

- estratégia;
- decisões ambíguas;
- criação original;
- síntese complexa;
- resolução de problemas difíceis;
- avaliação de risco elevado.

Usar modelo econômico para:

- checklist;
- classificação;
- extração;
- transformação estruturada;
- preenchimento de template;
- revisão formal e repetitiva.

Usar script, ferramenta ou comando para:

- renderização;
- conversão de arquivos;
- upload;
- compactação;
- execução de testes;
- movimentação de arquivos;
- processamento determinístico.

Não usar agente para aguardar um processo mecânico. Iniciar o processo e acompanhar apenas o estado necessário.

### 6. Projetar o contexto

Criar uma fonte única de verdade quando várias etapas compartilharem informações. Preferir arquivos curtos e especializados:

```text
PROJECT-SPEC.md
STYLE-GUIDE.md
CHECKLIST.md
PROJECT-STATE.md
HANDOFF.md
ERRORS-AND-GOTCHAS.md
```

Aplicar estas regras:

- referenciar arquivos em vez de repetir instruções longas;
- não fazer todos os agentes relerem o repositório inteiro;
- produzir handoff ao trocar de fase;
- remover histórico irrelevante;
- manter decisões aprovadas separadas de discussões antigas;
- registrar erros conhecidos para evitar redescoberta.

### 7. Definir limites operacionais

Estabelecer limites proporcionais ao projeto. Usar como padrão:

- nenhum subagente sem tarefa, entrada e saída explícitas;
- no máximo um nível de delegação, salvo necessidade clara;
- máximo de duas tentativas automáticas por item antes de reavaliar a abordagem;
- não reprocessar itens aprovados;
- não cancelar tarefas quase concluídas sem comparar o custo de terminar com o custo de reiniciar;
- revisão por amostragem para lotes de baixo risco;
- revisão completa para itens críticos ou reprovados;
- registrar uso de modelos caros e justificar sua necessidade.

### 8. Produzir o plano antes da execução

Usar o formato de `references/output-template.md`. O plano deve mostrar, no mínimo:

- estratégia escolhida;
- fases;
- dependências;
- o que será sequencial;
- o que será paralelo;
- executor de cada fase;
- arquivos compartilhados;
- limites de agentes e tentativas;
- principais riscos;
- critérios de conclusão.

Manter o plano proporcional ao trabalho. Para tarefas médias, usar de 5 a 12 linhas. Para projetos grandes, usar tabela ou seções curtas.

### 9. Executar e revisar

Depois do plano:

1. criar ou atualizar a especificação central;
2. executar primeiro as etapas bloqueantes;
3. paralelizar apenas as unidades autorizadas;
4. coletar resultados em formato uniforme;
5. validar critérios de qualidade;
6. refazer somente o necessário;
7. atualizar o estado e o handoff.

Se a realidade contrariar o plano, replanejar antes de criar mais agentes ou aumentar o paralelismo.

## Regras de economia

- Tratar tokens, tempo de máquina e tempo humano como custos diferentes.
- Não chamar render ou processamento computacional de “gratuito”; dizer “baixo custo de tokens” quando for o caso.
- Considerar o custo de coordenação, consolidação e divergência entre agentes.
- Considerar cache e reutilização de contexto quando a plataforma oferecer esses recursos.
- Preferir um agente por fase coerente, não um agente único infinito nem um agente por microtarefa.
- Reutilizar especificações, mas evitar contexto acumulado sem utilidade.

## Antipadrões proibidos

- criar vários agentes que releem os mesmos arquivos extensos;
- usar modelo avançado para tarefas mecânicas;
- paralelizar etapas com dependências ainda instáveis;
- delegar sem formato de saída comum;
- criar agentes apenas para aumentar a aparência de sofisticação;
- misturar planejamento, produção, renderização e revisão no mesmo contexto sem checkpoints;
- repetir integralmente regras que já estão em arquivos de referência;
- revisar todos os itens de um lote quando amostragem controlada for suficiente;
- continuar uma arquitetura ruim apenas porque já houve gasto; avaliar custo futuro, não apenas custo passado.

## Verificação final

Antes de concluir, confirmar:

- o paralelismo reduziu tempo sem duplicar contexto desnecessariamente;
- tarefas mecânicas foram retiradas dos modelos sempre que possível;
- cada agente tem função distinta e saída verificável;
- existe uma fonte única de verdade;
- o processo possui limites e condição de parada;
- somente itens reprovados retornam para correção;
- a arquitetura escolhida é mais simples do que alternativas equivalentes.
