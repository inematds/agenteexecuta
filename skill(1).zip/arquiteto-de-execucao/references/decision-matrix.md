# Matriz de decisão

Use esta matriz quando a escolha entre sequência, paralelo e híbrido não for evidente.

## Sinais para execução sequencial

Some um ponto para cada condição verdadeira:

- a tarefa depende diretamente da saída anterior;
- o contexto compartilhado é grande;
- decisões precisam permanecer consistentes;
- erros iniciais contaminariam várias tarefas;
- a consolidação de versões divergentes seria cara;
- o aprendizado de uma etapa melhora a seguinte.

## Sinais para execução paralela

Some um ponto para cada condição verdadeira:

- as tarefas são independentes;
- as entradas estão congeladas;
- cada saída pode ser validada isoladamente;
- o trabalho é mecânico ou determinístico;
- o contexto por tarefa é pequeno;
- a urgência é alta;
- existem recursos computacionais disponíveis.

## Interpretação

- predominância sequencial: executar em série;
- predominância paralela: executar simultaneamente com formato comum de saída;
- resultado equilibrado: usar arquitetura híbrida;
- alto custo de erro: centralizar planejamento e revisão, mesmo que a execução seja paralela.

## Exemplos

### Produção de 15 vídeos

- conceito, identidade e roteiro-base: sequencial;
- geração de variações após aprovação: paralelo;
- renderização: script em paralelo;
- revisão: centralizada por amostragem;
- correções: somente itens reprovados.

Resultado: híbrido.

### Pesquisa de mercado

- definição das perguntas e fontes: sequencial;
- coleta por segmentos independentes: paralelo;
- avaliação de evidências e síntese: sequencial;

Resultado: híbrido.

### Migração de sistema

- arquitetura, contrato de dados e estratégia: sequencial;
- migração de módulos independentes: paralelo controlado;
- testes automatizados: paralelo;
- integração e liberação: sequencial.

Resultado: híbrido com checkpoints rigorosos.

### Conversão de 500 arquivos

- validação de um arquivo de amostra: sequencial;
- conversão do lote: paralelo por workers;
- verificação estatística e amostragem: centralizada.

Resultado: paralelo mecânico com controle central.
