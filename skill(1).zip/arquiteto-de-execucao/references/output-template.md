# Modelo de saída

Adaptar a profundidade ao tamanho do projeto.

## Plano de execução

**Estratégia:** sequencial, paralela ou híbrida  
**Objetivo:** resultado final em uma frase  
**Premissas:** somente as premissas relevantes

| Fase | Tarefa | Modo | Executor | Dependência | Saída |
|---|---|---|---|---|---|
| 1 | ... | sequencial | modelo avançado | nenhuma | ... |
| 2 | ... | paralelo | script/modelo econômico | fase 1 | ... |

**Contexto compartilhado:** arquivos que funcionarão como fonte única de verdade.  
**Limites:** número de agentes, tentativas, amostragem e condições de parada.  
**Riscos:** duplicação, divergência, custo, erro ou atraso.  
**Critério de conclusão:** condições objetivas de aceite.

## Formato compacto

Para tarefas médias, usar:

```text
Estratégia: híbrida.
Sequencial: planejamento, especificação e revisão final.
Paralelo: tarefas independentes e processamento mecânico.
Executores: modelo avançado para decisões; modelo econômico para checklist; scripts para render e conversão.
Contexto: PROJECT-SPEC.md + CHECKLIST.md.
Limites: até 3 subagentes, 2 tentativas por item e retrabalho apenas dos reprovados.
Risco principal: repetição de contexto e divergência entre saídas.
```
